use db_retail
Select top 1 * from Customer
Select top 1 * from Transactions
Select top 1 * from prod_cat_info
DATA PREPARATION:
1)
use db_retail
Select COUNT (*) from Customer 
Union 
Select COUNT (*) from Transactions 
Union 
Select COUNT (*) from prod_cat_info
2)
use db_retail
Select Count(Distinct(transaction_id))as tot_trns from Transactions
Where Qty>0
3)
Use db_retail
Select CONVERT (date,tran_date,105) as tran_dates from Transactions
4) 
Use db_retail
Select DATEDIFF(YEAR,MIN(CONVERT(date,tran_date,105)),MAX(CONVERT(date,tran_date,105))) as diff_years,
DATEDIFF(MONTH,MIN(CONVERT(date,tran_date,105)),MAX(CONVERT(date,tran_date,105))) as diff_months,
DATEDIFF(DAY,MIN(CONVERT(date,tran_date,105)),MAX(CONVERT(date,tran_date,105))) as diff_days
from Transactions
5)
Select prod_cat,prod_subcat from prod_cat_info
where prod_subcat = 'DIY'

DATA ANALYSIS:
Select top 1 * from Customer
Select top 1 * from prod_cat_info
Select top 1 * from Transactions
1)
Select store_type,COUNT(*) as cnt from Transactions
group by Store_type
order by cnt desc
2)
Select gender,COUNT(*) as cnt from Customer
Where gender is not null
group by gender
3)
Select top 1 city_code, COUNT(*) as cnt from Customer
group by city_code
order by cnt desc
4)
Select prod_cat, prod_subcat from prod_cat_info
where prod_cat = 'Books'
5)
Select prod_cat_code,max(qty) as max_prod from Transactions
Group by prod_cat_code
6)
Select Sum(cast (total_amt as float)) as net_revenue from prod_cat_info as t1
join Transactions as t2
on t1.prod_cat_code = T2.prod_cat_code AND t1.prod_sub_cat_code = t2.prod_subcat_code
where prod_cat ='Books' OR prod_cat ='Electronics'
7)
Select count (*) as tot_cust from (
Select cust_id, count(distinct(transaction_id)) as cnt_trans from Transactions
where qty > 0
group by cust_id
having count(distinct(transaction_id)) > 10 
) as t5
8)
Select Sum(cast (total_amt as float)) as combined_revenue from prod_cat_info as t1
join Transactions as t2
on t1.prod_cat_code = T2.prod_cat_code AND t1.prod_sub_cat_code = t2.prod_subcat_code
where prod_cat in ('clothing','electronics') AND store_type = 'Flagship store' AND Qty >0
9)
Select prod_subcat, SUM(CAST (total_amt as float)) as tot_revenue from Customer as t1
join Transactions as t2
on t1.customer_Id = t2.cust_id
join prod_cat_info as t3
on t2.prod_cat_code = t3.prod_cat_code and t2.prod_subcat_code = t3.prod_sub_cat_code
where gender ='M'and prod_cat = 'Electronics'
group by prod_subcat
10)
Select t5.prod_subcat, percentage_sales,percentage_returns from (
Select top 5 prod_subcat, (SUM(CAST(total_amt as float))/(Select SUM(CAST(total_amt as FLOAT)) as tot_sales from Transactions where qty > 0)) as percentage_sales
 from prod_cat_info as t1
 join Transactions as t2
on t1.prod_cat_code = T2.prod_cat_code AND t1.prod_sub_cat_code = t2.prod_subcat_code
where qty > 0 
group by prod_subcat 
order by percentage_sales desc
) as t5
join
--Percentage of returns
(
Select prod_subcat, (SUM(CAST(total_amt as FLOAT))/(Select SUM(CAST(total_amt as FLOAT)) as tot_sales from Transactions where qty <0)) as percentage_returns
from prod_cat_info as t1
join Transactions as t2
on t1.prod_cat_code = T2.prod_cat_code AND t1.prod_sub_cat_code =t2.prod_subcat_code
where qty< 0
group by prod_subcat ) t6
on t5.prod_subcat = t6.prod_subcat
11)
Select top 1 * from Customer
Select top 1 * from Transactions
Select top 1 * from prod_cat_info

Select * from (
Select cust_id,DATEDIFF(year,dob,max_date) as Age, revenue from (
Select cust_id,dob,max(convert(date,tran_date,105)) as max_date,Sum(cast(total_amt as float)) as revenue from Customer as t1
join Transactions as t2
on t1.customer_Id = t2.cust_id
where qty>0
group by cust_id, DOB
) as A
      ) as B
where Age between 25 and 35
                            ) as C
Join(
 --Last 30 days of Transactions
 Select cust_id, convert(date,tran_date,105) as tran_date 
 from Transactions
 group by cust_id,convert(date,tran_date,105)
 having convert(date,tran_date,105) >= (Select dateadd(day, -30,max(convert(date,tran_date,105))) as cutoff_date from Transactions)
 ) as D
 on c.cust_id = d.cust_id
 
 12)
 Select prod_cat_code, Sum(returns) as tot_returns from (

 Select prod_cat_code,convert(date,tran_date,105) as tran_date , sum(qty) as Returns
 from Transactions
 Where Qty < 0
 group by prod_cat_code,convert(date,tran_date,105)
having convert(date, tran_date, 105) >=  (Select dateadd(MONTH, -3, MAX(CONVERT(date,tran_date,105))) as cutoff_date from Transactions)
) as A
Group by prod_cat_code
Order by tot_returns

13)
Select store_type , sum(cast(total_amt as float)) as revenue, sum(qty) as quantity 
from Transactions 
where qty >0 
group by store_type 
order by revenue desc, quantity desc
 
 14)
 Select prod_cat_code, avg(cast(total_amt as float)) as avg_revenue from Transactions
 where qty > 0
 group by prod_cat_code
 having avg(cast(total_amt as float)) >= (Select avg(cast(total_amt as float)) from Transactions where qty > 0)

 15)
 Select prod_subcat_code, sum(cast(total_amt as float)) as revenue , avg(cast(total_amt as float)) as avg_revenue
 from Transactions
 Where qty > 0 and prod_cat_code IN (Select top 5 prod_cat_code from Transactions
                                     where qty > 0
									  group by prod_cat_code
									  order by sum(qty) desc   )
group by prod_subcat_code









